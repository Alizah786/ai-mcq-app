import { useNavigate } from "react-router-dom";

export default function Login() {
  const navigate = useNavigate();

  return (
    <div style={{ minHeight: "100vh", display: "grid", placeItems: "center", background: "#f6f8fc" }}>
      <div style={{ width: 360, background: "#fff", padding: 24, borderRadius: 14, border: "1px solid #e5e7eb" }}>
        <h2 style={{ margin: 0, marginBottom: 6 }}>Sign in</h2>
        <p style={{ marginTop: 0, color: "#6b7280" }}>AI MCQ Classroom</p>

        <input placeholder="Email" style={{ width: "100%", padding: 10, marginBottom: 10, borderRadius: 10, border: "1px solid #e5e7eb" }} />
        <input placeholder="Password" type="password" style={{ width: "100%", padding: 10, marginBottom: 14, borderRadius: 10, border: "1px solid #e5e7eb" }} />

        <button
          onClick={() => navigate("/dashboard")}
          style={{ width: "100%", padding: 10, borderRadius: 10, border: "none", background: "#2563eb", color: "white", cursor: "pointer" }}
        >
          Login
        </button>
      </div>
    </div>
  );
}
