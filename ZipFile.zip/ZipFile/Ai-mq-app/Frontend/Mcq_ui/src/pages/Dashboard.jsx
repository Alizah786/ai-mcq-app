export default function Dashboard() {
  return (
    <div>
      <h2 style={{ marginTop: 0 }}>Dashboard</h2>
      <p>Select a class and quiz from the sidebar.</p>
    </div>
  );
}
