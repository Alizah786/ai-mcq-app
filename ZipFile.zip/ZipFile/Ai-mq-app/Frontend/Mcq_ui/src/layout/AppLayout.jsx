import { Outlet, useNavigate } from "react-router-dom";
import Sidebar from "../components/Sidebar";

export default function AppLayout() {
  // For now: assume logged-in; later we’ll enforce JWT
  return (
    <div style={{ display: "flex", minHeight: "100vh" }}>
      <Sidebar />
      <main style={{ flex: 1, padding: 24, background: "#f6f8fc" }}>
        <Outlet />
      </main>
    </div>
  );
}
