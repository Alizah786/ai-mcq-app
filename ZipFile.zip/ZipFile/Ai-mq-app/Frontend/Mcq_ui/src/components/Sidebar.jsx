import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Sidebar() {
  const navigate = useNavigate();
  const [openClassId, setOpenClassId] = useState(1);

  // Dummy data for now (we’ll load from API later)
  const classes = [
    {
      classId: 1,
      className: "Grade 9 Math",
      quizzes: [
        { quizId: 101, title: "Algebra Quiz" },
        { quizId: 102, title: "Geometry Quiz" },
      ],
    },
    {
      classId: 2,
      className: "Grade 10 Science",
      quizzes: [{ quizId: 201, title: "Physics MCQs" }],
    },
  ];

  return (
    <aside
      style={{
        width: 280,
        background: "#ffffff",
        borderRight: "1px solid #e5e7eb",
        padding: 16,
      }}
    >
      <div style={{ fontWeight: 700, fontSize: 18, marginBottom: 16 }}>
        AI MCQ Classroom
      </div>

      <div style={{ fontSize: 13, color: "#6b7280", marginBottom: 8 }}>
        My Classes
      </div>

      {classes.map((c) => (
        <div key={c.classId} style={{ marginBottom: 10 }}>
          <button
            onClick={() => setOpenClassId(openClassId === c.classId ? null : c.classId)}
            style={{
              width: "100%",
              textAlign: "left",
              padding: "10px 12px",
              borderRadius: 10,
              border: "1px solid #e5e7eb",
              background: openClassId === c.classId ? "#eef2ff" : "#fff",
              cursor: "pointer",
              fontWeight: 600,
            }}
          >
            {c.className}
          </button>

          {openClassId === c.classId && (
            <div style={{ marginTop: 8, paddingLeft: 10 }}>
              {c.quizzes.map((q) => (
                <div
                  key={q.quizId}
                  onClick={() => navigate(`/quiz/${q.quizId}`)}
                  style={{
                    padding: "8px 10px",
                    borderRadius: 10,
                    cursor: "pointer",
                    color: "#111827",
                  }}
                >
                  📄 {q.title}
                </div>
              ))}
            </div>
          )}
        </div>
      ))}

      <hr style={{ margin: "16px 0", borderColor: "#eee" }} />

      <button
        onClick={() => alert("Create Class (Teacher only) — coming next")}
        style={{
          width: "100%",
          padding: "10px 12px",
          borderRadius: 10,
          border: "1px solid #e5e7eb",
          background: "#fff",
          cursor: "pointer",
          marginBottom: 10,
        }}
      >
        ➕ Create Class
      </button>

      <button
        onClick={() => alert("Create Quiz (Teacher only) — coming next")}
        style={{
          width: "100%",
          padding: "10px 12px",
          borderRadius: 10,
          border: "1px solid #e5e7eb",
          background: "#fff",
          cursor: "pointer",
        }}
      >
        ➕ Create Quiz
      </button>
    </aside>
  );
}
